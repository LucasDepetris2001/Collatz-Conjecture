def prodcart(A, B):
    result = []
    for i in range(0, len(A)):
        for j in range(0, len(B)):
            if type(A[i]) != list:
                A[i] = [A[i]]
            temp = [num for num in A[i]]
            temp.append(B[j])
            result.append(temp)
    return result

def cart(A):
    temp = A[0]
    for i in range(1, len(A)):
        temp = prodcart(temp, A[i])
    return temp

def solstar(k):
    if k == 1:
        return [[2]]
    if k == 2:
        return [[2, 2], [4, 1]]
    A = cart([[1, 2] for i in range(k-1)])
    B = [[i for i in range(0, 3 ** (k-j-1))] for j in range(1, k)]
    C = cart(B)
    for c in C:
        c.append(0)
    h = [sol(k, a, c) for a in A for c in C]
    return h


def param(A):
    k = len(A)
    if k == 1:
        return [], []
    R = []
    M = []
    if A[0] % 6 == 2:
        R.append(1)
        M.append(A[0] - 2)
    else:
        R.append(2)
        M.append(A[0] - 4)
    for i in range(1, k-1):
        x = -dilog9(L(A[:i])) + 2
        if A[i] % 6 == x % 6:
            R.append(1)
            M.append(A[i] - modstar(x, 6))
        else:
            R.append(2)
            M.append(A[i] - modstar(x + 2, 6))
    del M[k - 2]
    X = []
    X.append(R)
    X.append(M)
    return X


def suma(A, B):
    k = len(A)
    if k == 1:
        return [2]
    ra, ma = param(A)
    rb, mb = param(B)
    ma.append(0)
    mb.append(0)
    rsum = [modstar(ra[i] + rb[i], 2) for i in range(k-1)]
    msum = [np.mod(ma[i] + mb[i], phi(3 ** (k-(i+1)+1))) for i in range(k-1)]
    N = [int(float(2 * rsum[0] + msum[0]))]
    for i in range(1, k-1):
        c = modstar(-dilog9(L(N)) + 2 * rsum[i], 6) + msum[i]
        N.append(c)
        N = [int(float(a)) for a in N]
    c = modstar(-dilog3(L(N)), 2)
    N.append(c)
    N = [int(float(a)) for a in N]
    return N


def gen(A):
    k = len(A)
    e = id(k)
    G = []
    G.append(e)
    if A == e:
        return G
    G.append(A)
    B = suma(A, A)
    while B != e:
        G.append(B)
        B = suma(B, A)
    return G

def ord(A):
    return len(gen(A))

def inver(A):
    H = gen(A)
    k = len(H)
    return H[k-1]

def id(k):
    return sol(k, [2 for i in range(k-1)], [0 for i in range(k)])

def elemord(k, m): #da una lista con los elementos de orden m en S*_k
    A = solstar(k)
    B = []
    for i in range(len(A)):
        x = A[i]
        if ord(x) == m:
            B.append(x)
    return B

def contord(k, m): #cuenta la cantidad de elementos de orden m en S*_k
    A = [ord(a) for a in solstar(k)]
    j = 0
    for i in range(len(A)):
        if A[i] == m:
            j += 1
    return j

def contord2(A, m): #cuenta la cantidad de elementos de orden m en Z_A[0]x...xZ_A[k-1], k = len(A)
    k = len(A)
    if k == 1:
        G = Group("add", A[0])
    else:
        G = Group(["add" for i in range(k)], A)
    B = G.go()
    j = 0
    for i in range(len(B)):
        if B[i] == m:
            j += 1
    return j

def xi(A, B):
    if not len(A) == len(B) + 1:
        print("dimension error")
        return
    B.append(0)
    B.append(0)
    return sol(len(A) + 1, A, [b // 6 for b in B])

def retrac(N): #tiene como entrada un N en S*_k y como salida la retracción de N, en S*_(k-1)
    k = len(N)
    if k == 2:
        return [2]
    if k == 1:
        return []
    x = param(N)
    rho = x[0]
    mu = x[1]
    del rho[k - 2]
    del mu[k - 3]
    mu = [np.mod(mu[i], phi(3 ** (k - (i + 1)))) for i in range(len(mu))]
    rho = [int(float(a)) for a in rho]
    mu = [int(float(a)) for a in mu]
    return xi(rho, mu)

def atrac(N, t): #tiene como entrada un N en S*_k y como salida la atracción de N (canónica, de orden o natural según el tipo)
    k = len(N)
    if t == 'can':
        return [2] + N
    x = param(N)
    rho = x[0]
    mu = x[1]
    if t == 'ord':
        return xi([2] + rho, [0] + mu)
    if t == 'nat':
        return xi(rho + [2], mu + [0])

def setisize(A):
    a = []
    for x in A:
        if not x in a:
            a.append(x)
    return a

def atrac2(A, j): #tiene como entrada un N en S*_k y como salida N^(j), j >= k
    while len(A) != j:
        A = atrac(A, 'nat')
    return A

def atrac3(A, j): #tiene como entrada un N en S*_k y como salida N^(j), j >= k
    while len(A) != j:
        A = atrac(A, 'ord')
    return A


def retrac2(A, j): #tiene como entrada un N en S*_k y como salida N^(j), j <= k
    while len(A) != j:
        A = retrac(A)
    return A

def suma1(A, B, t = '+'): #tiene como entradas dos elementos en S*_inf y como salida su suma (mayor o menor dependiendo del tipo t)
    k = len(A)
    l = len(B)
    if t == '+':
        m = max(k, l)
        A = atrac2(A, m)
        B = atrac2(B, m)
        return suma(A, B)
    if t == '-':
        n = min(k, l)
        A = retrac2(A, n)
        B = retrac2(B, n)
        return suma(A, B)

def suma2(A, B, t = '+'): #tiene como entradas dos elementos en S*_inf y como salida su suma (mayor o menor dependiendo del tipo t)
    k = len(A)
    l = len(B)
    if t == '+':
        m = max(k, l)
        A = atrac3(A, m)
        B = atrac3(B, m)
        return suma(A, B)
    if t == '-':
        n = min(k, l)
        A = retrac2(A, n)
        B = retrac2(B, n)
        return suma(A, B)


def mover(A, j): #tiene como entrada un N en S*_k y como salida N^(j)
    k = len(A)
    if j >= k:
        return atrac2(A, j)
    else:
        return retrac2(A, j)

def retracalt(N):
    k = len(N)
    if k == 2:
        return [2]
    if k == 1:
        return []
    x = param(N)
    rho = x[0]
    mu = x[1]
    rho = rho[1:]
    mu = mu[1:]
    rho = [int(float(a)) for a in rho]
    mu = [int(float(a)) for a in mu]
    return xi(rho, mu)

def retracalt2(N, j):
    while len(N) != j:
        N = retracalt(N)
    return N

def mover2(A, j):
    k = len(A)
    if j >= k:
        return atrac3(A, j)
    else:
        return retracalt2(A, j)

def inf(A):
    return [L(A), fact(L(A)), aux(L(A))]

def parte_basica(N): #tiene como entrada N en S_k y como salida la parte basica de N
    k = len(N)
    A = [modstar(N[i], phi(3 ** (k - (i + 1) + 1))) for i in range(k-1)] + [modstar(N[k-1], 2)]
    return [int(float(A[i])) for i in range(k)]

def traslacion(N): #tiene como entrada N en S_k y como salida la traslacion de N
    k = len(N)
    A = parte_basica(N)
    B = [N[i] - parte_basica(N)[i] for i in range(k)]
    return[B[i] // phi(3 ** (k - (i + 1) + 1)) for i in range(k)]

def invW(l):
    k = (l + 1) // 2
    factor = fact(3 * k - 1)
    if 2 in list(factor):
        n = factor[2] + 1
    else:
        n = 1
    A = list(filter(lambda x: x != 2, factor))
    B = [i ** factor[i] for i in A]
    return [int(np.prod(A)), n]