import numpy as np
import matplotlib.pyplot as plt


def collatz(n):
    q = np.array([])
    while n != 1:
        if n % 2 == 1:
            n = (3 * n + 1) // 2
            q = np.append(q, 1)
        else:
            n = n / 2
            q = np.append(q, 2)
    a = len(q)
    q0 = np.zeros(a)
    for i in range(a):
        q0[i] = q[a - i - 1]
    return q0.astype('int')


def cont(n):
    j = 0
    a = collatz(n)
    for i in range(len(a)):
        if a[i] == 1:
            j = j + 1
    return j


def graf(n_0, m):
    A = [cont(n) for n in range(1, n_0 + 1)]
    X = []
    for n in range(1, n_0 + 1):
        if A[n - 1] <= m and n % 2 == 1:
            X.append(n)
    B = [A[n - 1] for n in X]
    C = []
    for i in range(len(B)):
        l = 0
        q = B[i]
        for j in range(len(C)):
            if C[j] == q:
                l = 1
        if l == 0:
            C.append(q)
    C.sort()
    Y = []
    for i in range(len(X)):
        Y.append(A[X[i] - 1])
    plt.scatter(X, Y, s=5, c='r')
    x = np.linspace(0, n_0, 2)
    for i in range(len(C)):
        h = C[i]
        y = [h, h]
        if i % 2 == 0:
            plt.plot(x, y, 'k--', linewidth=0.5)
            plt.text(n_0 + 0.5, h, f"${h}$", fontsize='x-small', color='k')
        else:
            plt.plot(x, y, 'b--', linewidth=0.5)
            plt.text(n_0 + 0.5, h, f"${h}$", fontsize='x-small', color='b')
    plt.yticks([])
    plt.xticks([0, n_0])
    plt.show()

def graff(n_0, m):
    A = [cont(n) for n in range(1, n_0 + 1)]
    X = []
    for n in range(1, n_0 + 1):
        if A[n - 1] <= m:
            X.append(n)
    B = [A[n - 1] for n in X]
    C = []
    for i in range(len(B)):
        l = 0
        q = B[i]
        for j in range(len(C)):
            if C[j] == q:
                l = 1
        if l == 0:
            C.append(q)
    C.sort()
    Y = []
    for i in range(len(X)):
        Y.append(A[X[i] - 1])
    plt.scatter(X, Y, s=5, c='r')
    plt.yticks([])
    plt.xticks([0, n_0])
    plt.show()


def xi(k):
    return (2**totient(3**k)-1)//3**k


def numberToBase(n, b):
    if n == 0:
        return [0]
    digits = []
    while n:
        digits.append(int(n % b))
        n //= b
    return digits[::-1]