import numpy as np
from sympy import discrete_log


def Ltil(h):
    a = 1
    for k in range(len(h)):
        a = a * 2 ** h[k] - 3 ** k
    return a


def L(h):
    return Ltil(h) // 3 ** len(h)


def modstar(a, n):
    b = np.mod(a, n)
    if b != 0:
        return b
    else:
        return n


def sol(k, A, B):
    if k == 1:
        return [2 + B[0] * 2]
    N = [2 * A[0] + 6 * B[0]]
    for i in range(1, k - 1):
        c = -discrete_log(9, L(N), 2) + 2 * A[i]
        c = modstar(c, 6) + 6 * B[i]
        N.append(c)
        N = [int(float(a)) for a in N]
    c = -discrete_log(3, L(N), 2)
    c = modstar(c, 2) + 2 * B[k - 1]
    N.append(c)
    return [int(float(a)) for a in N]






